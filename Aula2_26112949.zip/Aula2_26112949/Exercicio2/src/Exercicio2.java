public class Exercicio2 {
    public static void main(String[] args) throws Exception {
        double valor1 = 50.25;
        double valor2 = 20.25;
        double valor3 = 80.50;
        double soma = valor1 + valor2 + valor3;
        System.out.println("A soma dos valores é " + soma);
    }
}
