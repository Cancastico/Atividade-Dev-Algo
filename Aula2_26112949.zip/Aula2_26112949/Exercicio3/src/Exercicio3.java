public class Exercicio3 {
    public static void main(String[] args) throws Exception {
        float valor1 = (float) 36.25;
        float valor2 = (float) 24.25;
        float valor3 = (float) 50.50;
        float soma = valor1 + valor2 + valor3;
        System.out.println("A soma dos valores é " + soma);
    }
}
