public class Exercicio1 {
    public static void main(String[] args) throws Exception {
        int valor1 = 45;
        int valor2 = 40;
        int valor3 = 35;
        int soma = valor1 + valor2 + valor3;
        System.out.println("A soma dos valores é " + soma);
    }
}
